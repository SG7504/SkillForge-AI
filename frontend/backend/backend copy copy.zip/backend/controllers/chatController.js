import { extractSkills } from "../services/skillExtractor.js";
import { generateQuestions } from "../services/questionGenerator.js";
import { evaluateAnswer } from "../services/evaluator.js";
import { generatePlan } from "../services/planner.js";
import { analyzeATS } from "../services/atsAnalyzer.js";

let sessions = {};

export const handleChat = async (req, res) => {
  const { jd, resume, answer } = req.body;
  const sessionId = req.ip;

  if (!sessions[sessionId]) {
    sessions[sessionId] = {
      started: false,
      skills: [],
      questions: [],
      answers: [],
      current: 0,
    };
  }

  const session = sessions[sessionId];

  try {
    // START
    if (!session.started) {
      if (!jd || !resume) {
        return res.json({
          step: "input",
          message: "Provide JD and Resume",
        });
      }

      const skillsData = await extractSkills(jd, resume);
      const atsResult = await analyzeATS(resume, jd);
      session.ats = atsResult;
      session.skills = skillsData?.required_skills || [];

      if (!session.skills.length) {
        return res.json({
          step: "error",
          message: "No skills found",
        });
      }

      session.questions = await generateQuestions(session.skills);
      session.questions = session.questions.slice(0, session.skills.length);

      session.started = true;

      return res.json({
        step: "question",
        message: session.questions[0],
      });
    }

    // ANSWER
    if (answer) {
      if (!session.skills[session.current]) {
        delete sessions[sessionId];
        return res.json({
          step: "error",
          message: "Session expired",
        });
      }

      const evalResult = await evaluateAnswer(
        session.skills[session.current],
        answer
      );

      session.answers.push({
        skill: session.skills[session.current],
        score: evalResult?.score ?? 5,
        level: evalResult?.level ?? "Intermediate",
        reason: evalResult?.reason ?? "No feedback",
      });

      session.current++;

      if (session.current < session.questions.length) {
        return res.json({
          step: "question",
          message: session.questions[session.current],
        });
      }

      // FINAL
      const roadmap = await generatePlan(session.answers);

      const finalResponse = {
      step: "result",
      results: session.answers,
      roadmap,
      ats: session.ats || {
      score: 0,
      strengths: [],
      improvements: [],
  },
};

      delete sessions[sessionId];

      return res.json(finalResponse);
    }

    return res.json({
      step: "error",
      message: "Invalid request",
    });
  } catch (err) {
    console.error("ERROR:", err);
    delete sessions[sessionId];

    return res.json({
      step: "error",
      message: "Something went wrong",
    });
  }
};