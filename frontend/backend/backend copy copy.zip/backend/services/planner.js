import { GoogleGenerativeAI } from "@google/generative-ai";
import { safeAI } from "../utils/safeAI.js";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

export async function generatePlan(results) {
  return await safeAI(async () => {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const prompt = `
You are an AI career coach.

Based on this assessment:

${JSON.stringify(results, null, 2)}

Create a personalized learning plan with:
- Skill gaps
- Weekly roadmap
- Resources
- Time estimate

Format clearly.
`;

    const result = await model.generateContent(prompt);
    return result.response.text();
  }, "Basic learning plan: Practice key skills and build projects.");
}