import { GoogleGenerativeAI } from "@google/generative-ai";
import { safeAI } from "../utils/safeAI.js";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

export async function evaluateAnswer(skill, answer) {
  return await safeAI(async () => {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const prompt = `
Evaluate this answer for skill: ${skill}

Answer:
${answer}

Return JSON:
{
  "score": number (0-10),
  "level": "Beginner | Intermediate | Advanced",
  "reason": "short explanation"
}
`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();

    try {
      return JSON.parse(text);
    } catch {
      return null;
    }
  }, {
    score: 5,
    level: "Intermediate",
    reason: "Fallback evaluation"
  });
}